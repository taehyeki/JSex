var express = require("express");
var mysql2 = require("mysql2");
var multer = require("multer");
var uploadMW = multer({
  dest: "upload",
});

var server = express();
var dbPool = mysql2.createPool({
  host: "localhost",
  user: "student_kth",
  password: "xogus123",
  database: "student_kth",
  connectionLimit: "10",
});

server.use(express.static("static"));
server.use(express.urlencoded());
server.set("view engine", "ejs");
server.set("views", "ejs");

server.get("/list", function (req, res) {
  var pageNum = parseInt(req.query.page);
  var pageStart = parseInt((pageNum - 1) / 5) * 5 + 1;

  var length, max;

  dbPool.query(
    "select * from board order by regtime desc",
    function (err, result) {
      length = result.length;
      max = Math.ceil(length / 5);
      for (var i = 0; i < length; i++) {
        if (result[i].regtime == null) continue;
        result[i].regtime = makeDate(result[i].regtime);
      }

      res.render("list", {
        result,
        num: (pageNum - 1) * 5,
        length,
        pageStart,
        max,
      });
    }
  );
});

server.get("/search", function (req, res) {
  var title = req.query.subject;

  dbPool.query(
    `select * from board where subject like '%${title}%' order by regtime desc`,
    function (err, result) {
      for (var i = 0; i < result.length; i++) {
        if (result[i].regtime == null) continue;
        result[i].regtime = makeDate(result[i].regtime);
      }
      res.render("search", { articles: result });
    }
  );
});

server.post("/write", uploadMW.single("attach"), function (req, res) {
  var { content, subject, author } = req.body;

  if (req.file) {
    var { filename, originalname } = req.file;

    dbPool.query(
      `insert into board set subject=?, content=?, author=?, regtime=NOW(), hitcount=0, filename=?, origin=?`,
      [subject, content, author, filename, originalname],
      function (err, result) {
        res.redirect("/list?page=1");
      }
    );
  } else {
    dbPool.query(
      `insert into board set subject=?, content=?, author=?, regtime=NOW(), hitcount=0`,
      [subject, content, author],
      function (err, result) {
        res.redirect("/list?page=1");
      }
    );
  }
});
server.get("/read", function (req, res) {
  var pageNum = req.query.page;
  var listNum = Math.ceil(pageNum / 5);
  dbPool.query(
    `select * from board where seq = ${pageNum}`,
    function (err, result) {
      var count = result[0].hitcount;
      var seq = result[0].seq;
      dbPool.query(
        `update board set hitcount=${count + 1} where seq=${seq}`,
        function (err, result) {}
      );
      res.render("read", {
        article: result[0],
        time: makeDate1(result[0].regtime),
        listNum,
      });
    }
  );
});

server.get("/download", function (req, res) {
  var index = req.query.index;
  dbPool.query(
    `select filename, origin from board where seq=${index}`,
    function (err, result) {
      res.attachment(result[0].origin);
      res.sendFile(__dirname + "/upload/" + result[0].filename);
    }
  );
});

server.listen(3000, function () {
  console.log("3000번 포트 서버");
});

function makeDate(date1) {
  var date = date1.toString().split(" ");
  var year, day, month;
  year = date[3];
  day = date[2];
  switch (date[1]) {
    case "Jan":
      month = "01";
      break;
    case "Feb":
      month = "02";
      break;
    case "Mar":
      month = "03";
      break;
    case "Apr":
      month = "04";
      break;
    case "May":
      month = "05";
      break;
    case "June":
      month = "06";
      break;
    case "July":
      month = "07";
      break;
    case "Aug":
      month = "08";
      break;
    case "Sept":
      month = "09";
      break;
    case "Oct":
      month = "10";
      break;
    case "Nov":
      month = "11";
      break;
    case "Dec":
      month = "12";
      break;
  }
  return year + "/" + month + "/" + day;
}
function makeDate1(date1) {
  var date = date1.toString().split(" ");
  var whool = date[4];
  var hour = whool.split(":")[0];
  var min = whool.split(":")[1];
  var sec = whool.split(":")[2];
  return hour + "시 " + min + "분 " + sec + "초";
}
