var fs = require('fs');
var input = process.env.QUERY_STRING;
input = decodeURIComponent(input);
var inputData = {};

if(input.indexOf('&') > 0){
  input.split('&').forEach(function(str){
    inputData[str.split('=')[0]] = str.split('=')[1];
  })
}

var article = fs.readFileSync('article.json');
article = article.toString();
article = JSON.parse(article);
article.unshift(inputData); 


fs.writeFileSync('article.json', Buffer.from(JSON.stringify(article)));

var httpContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta charset="UTF-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>List</title>
  <script>location.href = 'list.cgi.js';</script>
</head>
<body>
</body>
</html>`;


console.log('Content-Type: text/html');
console.log('Content-Length: ' + Buffer.from(httpContent).length);
console.log("");
process.stdout.write(httpContent);

